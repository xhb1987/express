"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var types_1 = require("./types");
var generateResponseMessage = function (data, statusCode, message) {
    if (statusCode === void 0) { statusCode = 200; }
    if (message === void 0) { message = types_1.Message.Success; }
    return ({
        statusCode: statusCode,
        message: message,
        data: data
    });
};
exports.default = generateResponseMessage;
