"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Message;
(function (Message) {
    Message["Success"] = "success";
    Message["Error"] = "error";
    Message["Info"] = "info";
    Message["Unknown"] = "unknown";
})(Message = exports.Message || (exports.Message = {}));
