"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var user_controller_1 = __importDefault(require("./user/user-controller"));
exports.UserController = user_controller_1.default;
var weather_controller_1 = __importDefault(require("./weather/weather-controller"));
exports.WeatherController = weather_controller_1.default;
var routing_controllers_1 = require("routing-controllers");
var typedi_1 = __importDefault(require("typedi"));
routing_controllers_1.useContainer(typedi_1.default);
