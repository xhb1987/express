"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var routing_controllers_1 = require("routing-controllers");
var types_1 = require("../../common/response-messge/types");
var response_message_1 = __importDefault(require("../../common/response-messge/response-message"));
var ErrorHandler = /** @class */ (function () {
    function ErrorHandler() {
    }
    ErrorHandler.prototype.error = function (error, request, response, next) {
        var message = response_message_1.default(error.message, error.httpCode, types_1.Message.Error);
        return response.json(message);
    };
    ErrorHandler = __decorate([
        routing_controllers_1.Middleware({ type: "after" })
    ], ErrorHandler);
    return ErrorHandler;
}());
exports.default = ErrorHandler;
