"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isTokenExist = function (token) {
    return token !== null || token !== undefined;
};
