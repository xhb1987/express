"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mongoose_1 = require("mongoose");
exports.userSchema = new mongoose_1.Schema({
    name: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    role: [
        {
            type: mongoose_1.SchemaTypes.ObjectId,
            ref: "role"
        }
    ]
}, { collection: "user" });
exports.UserModel = mongoose_1.model("user", exports.userSchema);
